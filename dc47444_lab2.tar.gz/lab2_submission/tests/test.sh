#! /bin/bash

./kernel_module/setup_cdma.sh

./test_dma.sh
